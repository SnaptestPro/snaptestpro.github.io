SnapTest Pro - GitHub EXCHANGE PACKAGE (Phase 6-10 update)
============================================================
Is zip me kya hai:
  01_DELETE_LIST.txt     -> GitHub se delete karne wali 96 files (group wise, reason ke saath)
  02_UPLOAD/part1,2,3    -> upload karne wali 167 files (141 nayi + 26 updated), folder structure ke saath
  03_AUTO_SCRIPTS/       -> apply.sh (Mac/Linux/Git Bash) aur apply.bat (Windows): delete + copy sab apne-aap
  04_CHECK_REPORT.txt    -> poori jaanch ki report (kya check hua, kya pass hua, kya baaki hai)

Ye package test kiya gaya hai: apne purane repo (base zip) par apply.sh chalane ke baad result
"SnapTestPro_FULL_CLEAN" ke BILKUL barabar aaya (0 difference).

------------------------------------------------------------
TARIKA 1 (SABSE SAHI AUR AASAAN) - script se
------------------------------------------------------------
1. Apna repo computer par clone karo:  git clone https://github.com/SnaptestPro/snaptestpro.github.io
2. Windows:  03_AUTO_SCRIPTS\apply.bat  C:\path\snaptestpro.github.io
   Mac/Linux/Git Bash:  bash 03_AUTO_SCRIPTS/apply.sh  ~/snaptestpro.github.io
   (Script pehle backup tag "backup-before-phase6-10" banata hai, naya branch "fix/phases-6-10" banata hai,
    question-bank.json ki backup copy repo ke bahar rakhta hai, phir delete + copy karta hai.)
3. Script ke baad:   git commit -m "Phase 6-10 update"   phir   git push -u origin fix/phases-6-10
4. GitHub par Pull Request kholo -> CI (Actions) green dekho -> tabhi "Merge" karo.

------------------------------------------------------------
TARIKA 2 - sirf browser se (github.dev)
------------------------------------------------------------
1. Apne repo ke page par keyboard me "." (dot) dabao -> VS Code browser me khulega.
2. 01_DELETE_LIST.txt ki files left panel me select karke Delete karo (Ctrl+click se multiple).
3. 02_UPLOAD/part1, part2, part3 ke ANDAR ki saari files/folders drag-drop karo repo ke root par
   ("Replace" chuno jab puche).
4. Source Control (Ctrl+Shift+G) -> message likho -> Commit & Push.

------------------------------------------------------------
TARIKA 3 - github.com website par seedha upload (sabse dheema)
------------------------------------------------------------
1. Delete: har file kholo -> "..." -> Delete file -> Commit (96 files, isliye Tarika 1/2 behtar hai).
2. Upload: Add file -> Upload files. GitHub ek baar me max 100 files leta hai, isliye part1, part2, part3
   ALAG-ALAG upload karo (part ke ANDAR ki cheezein drag karo, part folder khud nahi).
   Har part ke baad "Commit changes".

------------------------------------------------------------
UPLOAD KE BAAD - SAHI ORDER (bahut zaroori)
------------------------------------------------------------
1. Pehle website (GitHub Pages) deploy hone do aur CI check dekho.
2. Phir Cloudflare Worker deploy karo: push-worker/worker.js (naya /student/delete-account endpoint isi me hai).
3. SABSE LAST me Firestore rules deploy karo (firebase deploy --only firestore:rules).
   Kyunki naye rules registration par consent fields maangte hain; purani site ke saath naye rules chalane se
   registration ruk sakta hai.
4. Rules deploy karne se pehle:  npm run test:rules  (ya GitHub Actions ka "rules" job green) zaroor dekho.

Rollback: git checkout backup-before-phase6-10   aur Firebase Console > Rules history se purana release.

NOTE: Is zip me "www/" folder nahi hai - wo sirf build ka output hai (.gitignore me bhi hai), GitHub par kabhi upload nahi karna.
