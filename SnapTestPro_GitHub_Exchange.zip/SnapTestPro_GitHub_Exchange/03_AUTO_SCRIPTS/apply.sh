#!/usr/bin/env bash
# SnapTest Pro - exchange apply script (Mac / Linux / Git Bash)
# Use: bash apply.sh /path/to/your/local/snaptestpro.github.io
set -euo pipefail
REPO="${1:-}"
HERE="$(cd "$(dirname "$0")" && pwd)"
EX="$(cd "$HERE/.." && pwd)"
if [ -z "$REPO" ] || [ ! -d "$REPO/.git" ]; then echo "ERROR: apne local repo ka folder do (jisme .git ho). Example: bash apply.sh ~/snaptestpro.github.io"; exit 1; fi
REPO="$(cd "$REPO" && pwd)"
cd "$REPO"
echo "1) Backup tag + branch..."
git tag -f backup-before-phase6-10 >/dev/null
git checkout -B fix/phases-6-10 >/dev/null
if [ -f question-bank.json ]; then cp question-bank.json "../question-bank.json.BACKUP"; echo "   question-bank.json ki backup copy: $(cd .. && pwd)/question-bank.json.BACKUP"; fi
echo "2) Purani files delete (git rm)..."
while IFS= read -r p || [ -n "$p" ]; do
  p="${p%$'\r'}"; [ -z "$p" ] && continue
  git rm -q -f --ignore-unmatch -- "$p"
done < "$HERE/delete_paths.txt"
echo "3) Nayi / updated files copy..."
for part in "$EX"/02_UPLOAD/part*; do cp -R "$part"/. "$REPO"/; done
echo "4) git add..."
git add -A
git status --short | head -20
echo "..."
echo "DONE. Ab check karke ye chalao:  git commit -m 'Phase 6-10 update' && git push -u origin fix/phases-6-10"
echo "(Phir GitHub par Pull Request banake CI green hone par main me merge karo.)"
