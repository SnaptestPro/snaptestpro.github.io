@echo off
REM SnapTest Pro - exchange apply script (Windows)
REM Use: apply.bat C:\path\to\snaptestpro.github.io
setlocal enabledelayedexpansion
set "REPO=%~1"
set "HERE=%~dp0"
if "%REPO%"=="" goto usage
if not exist "%REPO%\.git" goto usage
for %%I in ("%REPO%") do set "REPO=%%~fI"
cd /d "%REPO%"
echo 1) Backup tag + branch...
git tag -f backup-before-phase6-10
git checkout -B fix/phases-6-10
if exist question-bank.json (
  copy /Y question-bank.json "..\question-bank.json.BACKUP" >nul
  echo    question-bank.json ki backup copy parent folder me rakh di.
)
echo 2) Purani files delete (git rm)...
for /f "usebackq delims=" %%F in ("%HERE%delete_paths.txt") do (
  git rm -q -f --ignore-unmatch -- "%%F"
)
echo 3) Nayi / updated files copy...
for /d %%P in ("%HERE%..\02_UPLOAD\part*") do (
  xcopy "%%P\*" "%REPO%\" /E /Y /I /Q >nul
)
echo 4) git add...
git add -A
git status --short
echo.
echo DONE. Ab check karke chalao:  git commit -m "Phase 6-10 update"  ^&^&  git push -u origin fix/phases-6-10
goto end
:usage
echo ERROR: apne local repo ka folder do (jisme .git ho). Example: apply.bat C:\snaptestpro.github.io
:end
endlocal
